package com.education.NagEd.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.education.NagEd.model.Course;

public interface courseRepository extends JpaRepository<Course, Long> {

}
