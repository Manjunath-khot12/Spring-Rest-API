package com.education.NagEd.service;

import java.util.List;

import com.education.NagEd.model.Course;

public interface CourseService {
   public void addCourse(Course course);
   public List<Course> getAllCourse();
   public Course updateCourse(Course course,long id);
   public void deleteCourse(long id);
}
