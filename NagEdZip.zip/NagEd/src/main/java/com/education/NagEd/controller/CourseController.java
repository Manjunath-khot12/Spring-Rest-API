package com.education.NagEd.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.education.NagEd.model.Course;
import com.education.NagEd.serviceImpl.CourseServiceImplimation;

@RestController
@RequestMapping("/NagEd")
public class CourseController {
	
	@Autowired
	CourseServiceImplimation courseServiceImplimation;
	
	@PostMapping("/addCourse")
	public ResponseEntity<String> addCourse(@RequestBody Course course)
	{
		courseServiceImplimation.addCourse(course);
		return ResponseEntity.ok("Course Added Successfully");
	}
  
	@GetMapping("/getAllCourse")
	public List<Course> getAllCourse()
	{
		return courseServiceImplimation.getAllCourse();
	}
	
	@PutMapping("/updateCourse/{id}")
	public ResponseEntity<Course> updateCourse(@RequestBody Course course,@PathVariable long id)
	{
		Course courses=courseServiceImplimation.updateCourse(course, id);
		return ResponseEntity.ok(courses);
	}
	
	@DeleteMapping("/deleteCourse/{id}")
	public ResponseEntity<String> deleteCourse(@PathVariable long id)
	{
		courseServiceImplimation.deleteCourse(id);
		return ResponseEntity.ok("course deleted ...");
	}
}
