package com.education.NagEd.serviceImpl;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.education.NagEd.model.Course;
import com.education.NagEd.repository.courseRepository;
import com.education.NagEd.service.CourseService;

@Service
public class CourseServiceImplimation implements CourseService {
    
	@Autowired
	courseRepository courseRepository;
	
	@Override
	public void addCourse(Course course) {
		courseRepository.save(course);
	}

	@Override
	public List<Course> getAllCourse() {
		return courseRepository.findAll();
	}

	@Override
	public Course updateCourse(Course updateCourse, long id) {
		return courseRepository.findById(id).map(course -> {
			course.setTitle(updateCourse.getTitle());
			course.setDescription(updateCourse.getDescription());
			course.setDuration(updateCourse.getDuration());
			return courseRepository.save(course);
		}).orElseThrow(()-> new RuntimeException("Record Not found"));
		
	}

	@Override
	public void deleteCourse(long id) {
	    courseRepository.deleteById(id);	
	}

}
