package com.education.NagEd;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class NagEdApplicationTests {

	@Test
	void contextLoads() {
	}

}
